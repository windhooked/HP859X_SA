U114 (8590-80159) Cypress PALC22V10-25

This is the memory decode PAL for the a HP 859xA series spectrum analyzer.
I have dumped it from my HP8591A, serial no 3108U01xxx with firmware Rev. F
(17.1.91). 

Use this with 4x 128k EPROMs. Machines with 4x 64k EPROMs (FW Rev. C, 3.1.90
and ealier) need 08590-80094.


2016-10-24 Dr. Patrick Sch�fer