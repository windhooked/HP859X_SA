U114 (8590-80094) Cypress PALC22V10-25

This is the memory decode PAL for the a HP 859xA series spectrum analyzer.
I have dumped it from my HP8591A, serial no 3037U01xxx with firmware Rev. C
(3.1.90). 

Use this with 4x 64k EPROMs. Machines with 4x 128k EPROMs (FW Rev. F, 17.1.91
and ealier) need 08590-80159.


2017-08-09 Dr. Patrick Sch�fer